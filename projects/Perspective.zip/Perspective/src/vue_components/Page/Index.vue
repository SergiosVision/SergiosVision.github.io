<template>
    <Carousel></Carousel>
</template>

<script>
    import Carousel from './Carousel.vue';
    export default {
        components: {
            Carousel: Carousel
        }

    }
</script>

<style>

</style>