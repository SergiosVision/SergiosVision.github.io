<template>
    <carousel :perPage="1"
              class="t-carousel">
        <slide>
            <img src="/images/slides/FirstSlide.jpg">
        </slide>
        <slide>
            <img src="/images/slides/slide2.jpg">
        </slide>
    </carousel>
</template>

<script>
    import { Carousel, Slide } from 'vue-carousel';

    export default {
        components: {Carousel, Slide}
    }
</script>

<style>

</style>