<template>
    <div class="t-lightBox">
        <div class="t-lightBoxImg">
            <img src="/images/newsImages/sergiosvision.jpg" alt="">
        </div>
        <div class="lightBoxInfo">
            <p>Инклюзивный полумарафон «Первый снег: разные возможности – цель одна»</p>
        </div>
        <div class="t-lightBoxControls">
            <div class="t-lightBoxLeftAndRight">
                <button type="button" class="t-lightBoxBtn t-lightBoxLeft">
                    <svg width="18" height="10" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M17 5H1m0 0l5.539 4M1 5l5.538-4" stroke="#4085D5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </button>
                <button type="button" class="t-lightBoxBtn t-lightBoxRight">
                    <svg width="18" height="10" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 5h16m0 0l-5.539-4M17 5l-5.539 4" stroke="#4085D5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </button>
            </div>
            <div class="t-lightBoxOpenWrapper">
                <button type="button" class="t-lightBoxBtn t-lightBoxOpen">
                    <svg width="16" height="16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M5.667 1H3a2 2 0 0 0-2 2v2.667M10.333 1H13a2 2 0 0 1 2 2v2.667M1 10.333V13a2 2 0 0 0 2 2h2.667m4.666 0H13a2 2 0 0 0 2-2v-2.667" stroke="#2574CF" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </button>
            </div>
        </div>
    </div>
</template>

<script>

    export default {


    }
</script>

<style>

</style>