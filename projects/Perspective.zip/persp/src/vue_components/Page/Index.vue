<template>
    <div class="t-mainPageHolder">
        <Carousel></Carousel>
        <div class="t-container">
            <section class="t-mainCard t-aboutCompany">
                <div class="t-mainSidesHolder">
                    <div class="t-leftSide">
                        <h2 class="t-mainTitle">Об организации</h2>
                        <div class="t-textHolder">
                            <p>Региональная общественная организация людей с инвалидностью «Перспектива» создана в 1997 г. На сегодняшний день мы — одна из ведущих организаций, отстаивающих права людей с инвалидностью в России.
                                <br>
                                <br>
                                Сотрудничая с государственными структурами, коммерческими и некоммерческими организациями, предоставляя услуги людям с инвалидностью, мы способствуем:
                            </p>
                        </div>
                        <ul class="t-mainList">
                            <li>Преодолению физических и психологических барьеров,  существующих в обществе по отношению к людям с инвалидностью.</li>
                            <li>Содействию людям с инвалидностью и их семьям в приобретении навыков  и знаний, необходимых для полноправного участия в жизни общества</li>
                            <li>Повышению эффективности работы  общественных организаций людей с инвалидностью.</li>
                        </ul>
                    </div>
                    <div class="t-rightSide">
                        <h4 class="t-middleTitle">Новости</h4>
                        <div class="t-newsCardsHolder">
                            <news-card>
                                <img slot="image" src="/images/newsImages/sergiosvision.jpg" alt="">
                                <h4 slot="title">В Санкт-Петербурге пройдет детский Фестиваль паралимпийского спорта</h4>
                                <h4 slot="titleSecond">Сопровождение в получении водительских прав категории «B»</h4>
                                <span slot="date">18 мая</span>
                            </news-card>
                            <news-card>
                                <img slot="image" src="/images/newsImages/bg.jpg" alt="">
                                <h4 slot="title">Сопровождение в получении водительских прав категории «B»</h4>
                                <h4 slot="titleSecond">Сопровождение в получении водительских прав категории «B»</h4>
                                <span slot="date">22 апр.</span>
                            </news-card>
                        </div>
                        <router-link tag="div" :to="'/news'" class="t-watchAll">
                            <span>Смотреть все</span>
                            <svg width="26" height="14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 7h24m0 0l-8.308-6M25 7l-8.308 6" stroke="#4085D5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                        </router-link>
                    </div>
                </div>
            </section>
            <section class="t-mainCard t-numbersAndCount">
                <div class="t-leftSide">
                    <h2 class="t-mainTitle">Цифры и факты</h2>
                    <div class="t-numberCardsHolder">
                        <div class="t-numberCard" v-for="item in numbersOutput">
                            <div class="t-numberCardCountWrapper">
                                <h2 class="t-numberCardCount">{{ item.count }}</h2>
                            </div>
                            <div class="t-numberCardTextWrapper">
                                <p>{{ item.msg }}</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="t-rightSide">
                    <h4 class="t-middleTitle">Фотолента</h4>
                    <div class="t-lightBoxWrapper">
                        <gallery></gallery>
                    </div>
                </div>
            </section>
            <section class="t-mainCard t-ourPrinciples">
                <h2 class="t-mainTitle">Наши принципы</h2>
                <div class="t-principlesCardHolder">
                    <div class="t-principlesCard" v-for="(item, index) in principles">
                        <div class="t-principlesCardNumber"><span>{{ index+1 }}</span></div>
                        <div class="t-principlesCardText">
                            <p>{{ item.msg }}</p>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</template>

<script>
    import Carousel from './Carousel.vue';
    export default {
        data() {
          return {
              pathToNumbers: '/JSON/info.json',
              pathToJson: '/JSON/principles.json',
              numbersOutput: [],
              principles: []
          }
        },
        components: {
            Carousel: Carousel
        },
        methods: {
            getNumbersInfo() {
                this.$http.get(this.pathToNumbers)
                    .then(response => response.json())
                    .then(json => {
                        this.numbersOutput = json;
                    }, error => {
                        console.error(error);
                    });
            },
            getTextForPrinciples() {
                this.$http.get(this.pathToJson)
                    .then(response => response.json())
                    .then(json => {
                            this.principles = json;
                    }, error => {
                        console.error(error);
                    });

            }
        },
        created() {
            this.getNumbersInfo();
            this.getTextForPrinciples();
        }

    }
</script>

<style>

</style>