<template>
    <header>
        <div class="t-headerLeftSide">
            <router-link tag="div" to="/" class="t-logo">
                <div class="t-logoLeftP">
                    <img src="/images/logo.png" alt="Logo Left">
                </div>
                <div class="t-logoRightP">
                    <span>Перспектива</span>
                </div>
            </router-link>
        </div>
        <div class="t-headerRightSide">
            <nav class="t-navigation">
                <ul class="t-mainList">
                    <router-link v-for="(item, index) in menuList"
                                 :key="index"
                                 :to="item.url"
                                 tag="li">
                        <a>{{ item.text }}</a>
                    </router-link>
                </ul>
            </nav>
            <div class="t-callAndQuestion">
                <button class="t-askQuestionBtn t-btn">Задать вопрос</button>
                <div class="t-numberHolder">
                    <span class="t-number">+7 (495) 725–39–82</span>
                    <span class="t-numberBottomTitle">единый номер по России</span>
                </div>
            </div>
        </div>
    </header>
</template>

<script>
    import { mapGetters } from 'vuex';
    export default {
        computed: {
            ...mapGetters('menu', {
                menuList: 'items'
            })
        }
    }
</script>

<style>

</style>