import Vue from 'vue';
import App from './vue_components/App.vue';

import {store} from './store'
import {router} from './routes'

import VueResource from 'vue-resource'

import NewsCard from './vue_components/Cards/NewsCard';
import Gallery from './vue_components/Page/Gallery';

Vue.use(VueResource);
Vue.http.options.root = '/';

Vue.component('news-card', NewsCard);
Vue.component('gallery', Gallery);

new Vue({
    el: '#app',
    store,
    router,
    render: h => h(App)
});
