<template>
	<section class="sv-container mainPage">
		<div class="sv-cardsHolder">
			<router-link @click.native="clearT" tag="div" :to="'/recipes/' + item.id" class="sv-card" v-for="(item, index) in recipesL" :key="index" :data-ckal="item.caloricity" :data-cook="item.cookTime">
				<div class="sv-cardImage">
					<img :src="item.thumbnail" :alt="item.title">
				</div>
				<div class="sv-cardContent">
					<div class="sv-cardTitle">
						<h3>{{ item.title }}</h3>
					</div>
					<div class="sv-cardInfo">
						<span class="sv-cardInfoCuisine">{{ item.cuisine.title }}</span>
						<span class="sv-cardInfoCaloricity">{{ item.caloricity }} kCal</span>
					</div>
					<div class="sv-cardDescription">
						<p>{{ item.description }}</p>
					</div>
				</div>
				<div class="sv-cardAction">
					<router-link @click.native="clearT" tag="a" :to="'/recipes/' + item.id">
						<span>Read more</span>
						<svg xmlns="http://www.w3.org/2000/svg" width="15" height="13" viewBox="0 0 15 13">
							<path fill="#FD9727" fill-rule="evenodd" d="M7.442 0l7.442 6.5L7.442 13l-1.315-1.148 5.192-4.554H0V5.702h11.319L6.127 1.148z"/>
						</svg>
					</router-link>
				</div>
			</router-link>
		</div>
	</section>
</template>

<script>
	import Vue from 'vue';
	import { mapGetters } from 'vuex';
	import  { store } from '../../store';
    import noUiSlider from 'nouislider';
	export default {
	    data() {
	        return {

			}
		},
		methods: {
	        clearT() {
				if(!this.modalActive) {
                    this.$store.dispatch('recipes/addCheckbox', null);
					[...document.querySelectorAll('.sv-checkBoxGroup input')].map(data => {
				        data.checked = false;
					});
				}
			},
		},
        computed: {
            ...mapGetters('modals', {
                modalActive: 'modalActive'
            }),
            recipesL() {
				return this.$store.getters['recipes/loadedRecipes'];
			},
            loadedCheckEls() {
                return this.$store.getters['recipes/loadedCheckEls'];
            },

        },
		beforeRouteEnter(to, from, next) {
			Vue.http.get('https://test.space-o.ru/list.json')
				.then(resposne => resposne.json())
				.then(json => {
				    store.dispatch('recipes/loadRecipes', json.recipes);
				    next();
				})
		},
		mounted() {
			let getButtons = document.querySelectorAll('.ripple');
            setTimeout(() => {
                getButtons.forEach(data => {
                    data.addEventListener('click', (e) => {
						
                        if(data.getElementsByClassName('rippleActive').length > 0) {
                            data.removeChild(data.childNodes[1]);
                        }

                        let circle = document.createElement('div');
                        data.appendChild(circle);

                        let d = Math.max(data.clientWidth, data.clientHeight);
                        circle.style.width = circle.style.height = d + 'px';


                        circle.style.left = e.clientX - data.getBoundingClientRect().left - d / 2 + 'px';
                        circle.style.top = e.clientY - data.getBoundingClientRect().top - d / 2 + 'px';

                        circle.classList.add('rippleActive');


                    })
                })
			},0)
		}
	}
</script>