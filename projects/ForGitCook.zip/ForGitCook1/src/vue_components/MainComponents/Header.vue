<template>
    <header :class="{'sv-yellow sv-yellowFilterHide': $route.path !== '/'}">
        <div class="sv-headerMainContainer">
            <filter-app></filter-app>
            <section class="sv-headerTop">
                <div class="sv-headerLogo">
                    <router-link tag="h1" to="/">AirRecipes</router-link>
                </div>
                <div class="sv-headerSearchBar">
                    <svg xmlns="http://www.w3.org/2000/svg" width="23" height="24" viewBox="0 0 23 24"><defs><filter id="a" width="100.8%" height="115.6%" x="-.3%" y="-6.2%" filterUnits="objectBoundingBox"><feOffset dy="1" in="SourceAlpha" result="shadowOffsetOuter1"/><feGaussianBlur in="shadowOffsetOuter1" result="shadowBlurOuter1" stdDeviation="1.5"/><feColorMatrix in="shadowBlurOuter1" result="shadowMatrixOuter1" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.34 0"/><feMerge><feMergeNode in="shadowMatrixOuter1"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><path fill="#FFF" fill-rule="evenodd" d="M12.5 11h-.79l-.28-.27A6.47 6.47 0 0 0 13 6.5 6.5 6.5 0 1 0 6.5 13c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L17.49 16l-4.99-5zm-6 0C4.01 11 2 8.99 2 6.5S4.01 2 6.5 2 11 4.01 11 6.5 8.99 11 6.5 11z" filter="url(#a)" transform="translate(3 2)"/></svg>
                    <div class="sv-group">
                        <input type="text" required>
                        <span class="bar"></span>
                        <label>Search</label>
                    </div>
                </div>
            </section>
            <section class="sv-headerBottom">
                <h1 class="sv-headerBottomTitle">Find the best recipes!</h1>
            </section>
        </div>
    </header>
</template>

<script>
    export default {
        data() {
            return {

            }
        },

    }
</script>

<style>

</style>