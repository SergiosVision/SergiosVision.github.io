<template>
    <div class="sv-filterWrapper">
        <button class="sv-filterButton" @click="showModal">
            <svg xmlns="http://www.w3.org/2000/svg" width="23" height="16" viewBox="0 0 23 16"><path fill="#FFF" fill-rule="evenodd" d="M4 9.23V6.77h15v2.46H4zM.25.5h22.5v2.52H.25V.5zm8.73 15v-2.52h5.04v2.52H8.98z"/></svg>
        </button>
        <transition name="modal">
            <div class="sv-filterDialog" v-show="modalActive">
                <div class="sv-filterCtrls">
                    <div class="sv-filterClear">
                        <span>Clear all</span>
                    </div>
                    <div class="sv-filterFilter">
                        <button>See recipes</button>
                    </div>
                </div>
                <div class="sv-filterBody">
                    <div class="sv-filterAccordion">
                        <div class="sv-filterAccordionTrigger" :class="cl" @click="toggleAccordion">
                            <h3>Cuisine</h3>
                            <svg xmlns="http://www.w3.org/2000/svg" width="10" height="6" viewBox="0 0 10 6"><path fill="#000" fill-rule="evenodd" d="M8.82 6L5 2.272 1.18 6 0 4.854 5 0l5 4.854z"/></svg>
                        </div>
                        <transition name="accordion"
                                    v-on:before-enter="beforeEnter" v-on:enter="enter"
                                    v-on:before-leave="beforeLeave" v-on:leave="leave">
                            <div class="sv-filterAccordionBody" v-show="isOpen">
                                <ul class="sv-mainList">
                                    <li v-for="(item, index) in categoriesList" :key="index">
                                        <div class="sv-checkBoxGroup">
                                            <label class="material-checkbox">
                                                <input :id="item.title.toLowerCase()" type="checkbox">
                                                <span>{{ item.title }}</span>
                                            </label>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </transition>
                    </div>
                    <div class="sv-filterRangeHolder">
                        <div class="sv-caloriesRange default">
                            <h3>Calories Range</h3>
                            <div id="caloriesRange"></div>
                        </div>
                        <div class="sv-cookRange default">
                            <h3>Cooking Time</h3>
                            <div id="cookingRange"></div>
                        </div>
                    </div>
                </div>
            </div>
        </transition>
    </div>
</template>

<script>
    import Vue from 'vue';
    import { mapMutations, mapGetters } from 'vuex';
    import  { store } from '../../store';
    import Range from 'nouislider';
    export default {
        data() {
            return {
                categoriesList: [
                    {
                        title: 'Chinese'
                    },
                    {
                        title: 'Caribbean'
                    },
                    {
                        title: 'French'
                    },
                    {
                        title: 'Greek'
                    },
                    {
                        title: 'Indian'
                    }
                ],
                isOpen: true,
            }
        },
        methods: {
            ...mapMutations('modals', ['showModal', 'hideModal']),
            toggleAccordion(index) {
                if(this.isOpen === false) {
                    this.isOpen = true;
                } else {
                    this.isOpen = false;
                }
            },
            beforeEnter: function(el) {
                el.style.maxHeight = '0';
            },
            enter: function(el) {
                el.style.maxHeight = el.scrollHeight + 'px'
            },
            beforeLeave: function(el) {
                el.style.maxHeight = el.scrollHeight + 'px';
            },
            leave: function(el) {
                el.style.maxHeight = '0';
            },
            callCaloriesSlider(item) {
                Range.create(item.caloriesRange, {
                    start: [18, 60],
                    connect: true,
                    step: 1,
                    range: {
                        'min': 18,
                        'max': 60
                    }
                })
            },
            callCookingSlider(item) {
                Range.create(item.cookingRange, {
                    start: [18, 60],
                    connect: true,
                    step: 1,
                    range: {
                        'min': 18,
                        'max': 60
                    }
                })
            },
        },
        computed: {
            ...mapGetters('modals', {
                modalActive: 'modalActive'
            }),
            cl() {return this.isOpen === true ? 'is-opened' : '';},
        },
        mounted() {
            let getRanges = {
                caloriesRange: document.querySelector('#caloriesRange'),
                cookingRange: document.querySelector('#cookingRange')
            };
            this.callCaloriesSlider(getRanges);
            this.callCookingSlider(getRanges);
        }

    }
</script>