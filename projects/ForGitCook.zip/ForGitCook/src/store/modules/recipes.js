export default {
    namespaced: true,
    state: {
        loadedRecipes: [],
        loadedRecipe: null
    },
    mutations: {
        setLoadedRecipes(state, payload) {
            state.loadedRecipes = payload;
        },
        setLoadedRecipe(state, payload) {
            state.loadedRecipe = payload;
        }
    },
    actions: {
        loadRecipes({commit}, data) {
            commit('setLoadedRecipes', data);
        },
        loadRecipe({commit}, data) {
            commit('setLoadedRecipe', data);
        }
    },
    getters: {
        loadedRecipes(state) {
            return state.loadedRecipes;
        },
        loadedRecipe(state) {
            return state.loadedRecipe;
        }
    }
}