import Vue from 'vue';
import App from './vue_components/App.vue';

import {store} from './store'
import {router} from './routes'

import VueResource from 'vue-resource'

import NewsCard from './vue_components/Cards/NewsCard';
import Gallery from './vue_components/Page/Gallery';
import MainDialog from './vue_components/Modals/UniversalModal'

Vue.use(VueResource);
Vue.http.options.root = '/';

Vue.component('news-card', NewsCard);
Vue.component('gallery', Gallery);
Vue.component('main-dialog', MainDialog);

router.beforeEach((to, form, next) => {
    document.title = to.meta.title;
    // setTimeout(() => {
    //     window.scrollTo(0,0)
    // }, 100);
    next();
});

new Vue({
    el: '#app',
    store,
    router,
    render: h => h(App),
});
