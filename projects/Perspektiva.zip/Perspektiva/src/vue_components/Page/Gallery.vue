<template>
    <div class="t-lightBoxCard">
        <div class="t-lightBoxCardInner">
            <div class="t-lightBoxTape" :style="{ width: innerWidth + 'px', transform: 'translate3d(-'+ sideCtrl +'px, 0, 0)' }">
                <div class="t-lightBoxImgAndInfo" v-for="(item, index) in tape" :key="index" :style="{ width: singleWidth + 'px' }">
                    <div class="t-lightBoxImg">
                        <img :src="item.img" :alt="item.title">
                    </div>
                    <div class="lightBoxInfo">
                        <p>{{ item.title }}</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="t-lightBoxControls">
            <div class="t-lightBoxLeftAndRight">
                <button @click.prevent="pervBtn" type="button" class="t-lightBoxBtn t-lightBoxLeft">
                    <svg width="18" height="10" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M17 5H1m0 0l5.539 4M1 5l5.538-4" stroke="#4085D5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </button>
                <button @click.prevent="nextBtn" type="button" class="t-lightBoxBtn t-lightBoxRight">
                    <svg width="18" height="10" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 5h16m0 0l-5.539-4M17 5l-5.539 4" stroke="#4085D5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </button>
            </div>
            <div class="t-lightBoxOpenWrapper">
                <button @click.prevent="showBox" type="button" class="t-lightBoxBtn t-lightBoxOpen">
                    <svg width="16" height="16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M5.667 1H3a2 2 0 0 0-2 2v2.667M10.333 1H13a2 2 0 0 1 2 2v2.667M1 10.333V13a2 2 0 0 0 2 2h2.667m4.666 0H13a2 2 0 0 0 2-2v-2.667" stroke="#2574CF" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </button>
            </div>
        </div>
        <div class="t-lightBoxInside" v-if="visible">
            <div @click.prevent="hideBox" class="t-overlay"></div>
        </div>
    </div>
</template>

<script>
    export default {
        props: {
            tape: Array,
            itemPerSlid: {
                type: null,
                default: 1
            },
        },
        data() {
          return {
              innerWidth: 0,
              singleWidth: 0,
              currentIndex: 0,
              tapeL: this.tape.length,
              visible: false
          }
        },
        computed: {
            sideCtrl() {
                return this.currentIndex * this.singleWidth;
            }
        },
        methods: {
            pervBtn() {
                if(this.currentIndex !== 0) {
                    this.currentIndex--;
                }
            },
            nextBtn() {
                if(this.currentIndex !== this.tapeL -1) {
                    this.currentIndex++;
                }
            },
            showBox() {
                this.visible = true;
            },
            hideBox() {
                this.visible = false;
            }
        },
        mounted() {
            this.singleWidth = this.$el.clientWidth / this.itemPerSlid;
            this.innerWidth = this.singleWidth * this.tapeL;
        },
    }
</script>

<style>

</style>