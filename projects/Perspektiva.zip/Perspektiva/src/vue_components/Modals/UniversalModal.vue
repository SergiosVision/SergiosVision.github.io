<template>
    <div class="t-mainDialogWrapper">
        <div class="t-dialogOverlay"></div>
        <div class="t-mainDialog">
            <div class="t-mainDialogHeader">
                <div class="t-mainDialogMainImg">
                    <slot name="mainImage"></slot>
                </div>
            </div>
            <div class="t-mainDialogBody">
                <div class="t-mainDialogDateAndTag">
                    <div class="t-mainDialogTag"><slot name="tag"></slot></div>
                    <div class="t-mainDialogDate">
                        <svg width="16" height="18" viewBox="0 0 16 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12.444 8.1H3.556v1.8h8.888V8.1zm1.778-6.3h-.889V0h-1.777v1.8H4.444V0H2.667v1.8h-.89C.792 1.8.01 2.61.01 3.6L0 16.2c0 .99.791 1.8 1.778 1.8h12.444C15.2 18 16 17.19 16 16.2V3.6c0-.99-.8-1.8-1.778-1.8zm0 14.4H1.778V6.3h12.444v9.9zm-4.444-4.5H3.556v1.8h6.222v-1.8z" fill="#000"/></svg>
                        <slot name="date"></slot>
                    </div>
                </div>
                <div class="t-mainDialogTitleWrapper"><slot name="title"></slot></div>
                <div class="t-mainDialogSocialSharingWrapper">
                    <span>поделиться в соцсетях:</span>
                    <ul class="t-mainList">
                        <li><a href="#">f</a></li>
                        <li><a href="#">ok</a></li>
                        <li><a href="#">vk</a></li>
                        <li><a href="#">tw</a></li>
                        <li><a href="#">G+</a></li>
                    </ul>
                </div>
                <div class="t-mainDialogOutputContentWrapper"><slot name="content"></slot></div>
            </div>
            <div class="t-mainDialogFooter">
                <div class="t-mainDialogSocialSharingWrapper">
                    <span>поделиться в соцсетях:</span>
                    <ul class="t-mainList">
                        <li><a href="#">f</a></li>
                        <li><a href="#">ok</a></li>
                        <li><a href="#">vk</a></li>
                        <li><a href="#">tw</a></li>
                        <li><a href="#">G+</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</template>



<script>
    export default {
        data() {
            return {

            }
        },
        methods: {

        },
    }
</script>

<style>

</style>