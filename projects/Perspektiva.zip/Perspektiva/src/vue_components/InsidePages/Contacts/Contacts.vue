<template>
    <div class="t-wrapperContacts t-mainInsideContainer">
        <div class="t-insideBgHolder">
            <div class="t-insideBgHolderOverlay">
                <h3 class="t-insideBgHolderTitle">Контакты</h3>
            </div>
        </div>
        <div class="t-container">
            <h3>Тут Контент</h3>
        </div>
    </div>
</template>



<script>
    export default {

    }
</script>

<style>

</style>