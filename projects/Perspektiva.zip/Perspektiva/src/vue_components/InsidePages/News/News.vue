<template>
    <div class="t-wrapperNews t-mainInsideContainer">
        <div class="t-insideBgHolder">
            <div class="t-insideBgHolderOverlay">
                <h3 class="t-insideBgHolderTitle">Новсти</h3>
            </div>
        </div>
        <div class="t-container">
            <div class="t-newsCardsHolder">
                <news-card v-for="(item, index) in newsArr" :key="index">
                    <img slot="image" :src="item.img" alt="">
                    <h4 slot="title">{{ item.title }}</h4>
                    <h4 slot="titleSecond">{{ item.title }}</h4>
                    <span slot="date">{{ item.date }}</span>
                </news-card>
            </div>
            <button class="t-btn t-moreBtn">Больше Новостей</button>
        </div>
    </div>
</template>



<script>
    export default {
        data() {
            return {
                newsLink: '/JSON/news.json',
                newsArr: []
            }
        },
        methods: {
            getAllNews() {
                this.$http.get(this.newsLink)
                    .then(response => response.json())
                    .then(json => this.newsArr = json)
                    .catch(error => console.error(error))
            }
        },
        created() {
            this.getAllNews();
        }
    }
</script>

<style>

</style>