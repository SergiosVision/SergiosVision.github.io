<template>
    <div class="t-wrapperNews t-mainInsideContainer">
        <div class="t-insideBgHolder">
            <div class="t-insideBgHolderOverlay">
                <h3 class="t-insideBgHolderTitle">Новсти</h3>
            </div>
        </div>
        <div class="t-container">
            <div v-if="loading" style="text-align: center">Загрузка</div>
            <div class="t-newsCardsHolder" v-else>
                <news-card v-for="(item, index) in news" :key="index">
                    <img slot="image" :src="item.img" alt="">
                    <h4 slot="title">{{ item.title }}</h4>
                    <h4 slot="titleSecond">{{ item.title }}</h4>
                    <span slot="date">{{ item.date }}</span>
                    <router-link tag="div" :to="{name: 'NewsInside', params: {slug: item.title}}" slot="readMore" class="t-newsCardReadMore">
                        <svg width="20" height="13" fill="none" xmlns="http://www.w3.org/2000/svg"><path opacity=".8" d="M19 5.714H7.545C1 5.714 1 12 1 12m18-6.286L11.636 1M19 5.714l-7.364 4.715" stroke="#2574CF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                        <span>Читать</span>
                    </router-link>
                </news-card>
            </div>
            <button class="t-btn t-moreBtn">Больше Новостей</button>
        </div>
        <router-view></router-view>
    </div>
</template>



<script>
    export default {
        data() {
            return {

            }
        },
        computed: {
            news() {return this.$store.getters.loadedNews},
            loading() {return this.$store.getters.loading;}
        },
        created() {
            this.$store.dispatch('loadNews');
        }
    }
</script>

<style>

</style>