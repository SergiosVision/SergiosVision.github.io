<template>
    <div class="t-wrapperServices t-mainInsideContainer">
        <div class="t-insideBgHolder">
            <div class="t-insideBgHolderOverlay">
                <h3 class="t-insideBgHolderTitle">Услуги</h3>
            </div>
        </div>
        <div class="t-container">
            <div v-if="loading" style="text-align: center">Загрузка</div>
            <div class="t-servicesCardsHolder" v-else>
                <div class="t-servicesCard" v-for="(item, index) in services" :key="index">
                    <div class="t-servicesCardImgWrapper">
                        <img :src="item.img">
                    </div>
                    <div class="t-servicesCardInfo">
                        <div class="t-servicesCardTitle">
                            <h3>{{ item.title }}</h3>
                        </div>
                        <router-link tag="div" :to="{ name: 'ServicesInside', params: {slug: item.title} }" class="t-servicesCardReadMore">
                            <svg width="20" height="13" viewBox="0 0 20 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path opacity=".8" d="M19 5.714H7.545C1 5.714 1 12 1 12m18-6.286L11.636 1M19 5.714l-7.364 4.715" stroke="#2574CF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            <span>Подробнее</span>
                        </router-link>
                    </div>
                </div>
            </div>
            <button class="t-btn t-moreBtn">Больше услуг</button>
        </div>
        <router-view></router-view>
    </div>
</template>



<script>
    export default {
        data() {
            return {
            }
        },
        methods: {},
        computed: {
            services() {return this.$store.getters.loadedServices},
            loading() {return this.$store.getters.loading;}
        },
        created() {
            this.$store.dispatch('loadServices');
        }
    }
</script>
