<template>
    <div class="t-wrapperUseful t-mainInsideContainer">
        <div class="t-insideBgHolder">
            <div class="t-insideBgHolderOverlay">
                <h3 class="t-insideBgHolderTitle">Полезное</h3>
            </div>
        </div>
        <div class="t-container">
            <div class="t-usefulCardsHolder">
                <div class="t-usefulCard" v-for="(item, index) in usefulArr">
                        <div class="t-usefulCardImgHolder">
                        <img :src="item.img">
                    </div>
                    <div class="t-usefulCardInfoHolder">
                        <div class="t-usefulCardInfo">
                            <h3>{{ item.title }}</h3>
                        </div>
                        <div class="t-usefulCardReadMore">
                            <div class="t-useFulCardReadMoreWrInside">
                                <svg width="20" height="13" viewBox="0 0 20 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path opacity=".8" d="M19 5.714H7.545C1 5.714 1 12 1 12m18-6.286L11.636 1M19 5.714l-7.364 4.715" stroke="#2574CF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                <span>Читать</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <button class="t-btn t-moreBtn">Больше статей</button>
        </div>
    </div>
</template>



<script>
    export default {
        data() {
            return {
                usefulLink: '/JSON/useful.json',
                usefulArr: []
            }
        },
        methods: {
            getUseful() {
                this.$http.get(this.usefulLink)
                    .then(response => response.json())
                    .then(json => this.usefulArr = json)
                    .catch(error => console.error(error));
            }
        },
        created() {
            this.getUseful();
        }
    }
</script>

<style>

</style>