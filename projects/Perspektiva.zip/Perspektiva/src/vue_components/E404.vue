<template>
	<div class="t-mainInsideContainer">
		<h1>Такой Страницы нет :(</h1>
		<hr>
		<router-link :to="'/'">На главную?</router-link>
	</div>
</template>

<script>
	export default {
		
	}
</script>