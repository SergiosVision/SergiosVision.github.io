import Vue from 'vue';
import VueRouter from 'vue-router';

Vue.use(VueRouter);

import Index from './vue_components/Page/Index';
import Services from './vue_components/InsidePages/Services/Services';
import Service from './vue_components/InsidePages/Services/Service';
import News from './vue_components/InsidePages/News/News';
import Useful from './vue_components/InsidePages/Useful/Useful';
import Contacts from './vue_components/InsidePages/Contacts/Contacts';
import E404 from './vue_components/E404'

const routes = [
    {
        path: '/',
        name: 'Home',
        component: Index,
        meta: {
            title: 'Перспектива - Главная'
        }
    },
    {
        path: '/services',
        name: 'Services',
        component: Services,
        meta: {
            title: 'Услуги'
        },
        children: [
            {
                path: ':id',
                name: 'ServicesInside',
                component: Service,
                meta: {
                    title: 'Услуги'
                },
                props: {id: null}
            }
        ]
    },
    // {
    //     path: '/services/:id',
    //     name: 'ServicesInside',
    //     component: Service,
    //     meta: {
    //         title: 'Услуги'
    //     }
    // },
    {
        path: '/news',
        name: 'News',
        component: News,
        meta: {
            title: 'Новости'
        }
    },
    {
        path: '/news/:id',
        name: 'NewsInside',
        component: News,
        meta: {
            title: 'Новости'
        }
    },
    {
        path: '/useful',
        name: 'Useful',
        component: Useful,
        meta: {
            title: 'Полезное'
        }
    },
    {
        path: '/contacts',
        name: 'Contacts',
        component: Contacts,
        meta: {
            title: 'Контакты'
        }
    },
    {
        path: '*',
        component: E404,
        meta: {
            title: 'Ничего не найдено :('
        }
    }
];

export const router = new VueRouter({
    routes,
    mode: 'history'
});