import Vue from 'vue';
export default {
    state: {
        loadedNews: []
    },
    mutations: {
        setLoadedNews(state, payload) {
            state.loadedNews = payload;
        }
    },
    actions: {
        loadNews({commit}) {
            commit('setLoading', true);
            Vue.http.get('/JSON/news.json')
                .then(response => response.json())
                .then(json => {
                    commit('setLoadedNews', json);
                    commit('setLoading', false);
                })
                .catch(error => {
                    console.error(error);
                    commit('setLoading', false);
                })
        }
    },
    getters: {
        loadedNews(state) {
            return state.loadedNews;
        },
        loadedNewsSingle(state) {
            return newsId => {
                return state.loadedNews.find(newsOnce => {
                    return newsOnce.title === newsId;
                })
            }
        },
        featuredNews(state, getters) {
            return getters.loadedNews.slice(0,2);
        }
    }
}