import Vue from  'vue';
export default {
    state: {
        loadedUsf: []
    },
    mutations: {
        setLoadedUsf(state, payload) {
            state.loadedUsf = payload;
        }
    },
    actions: {
        loadUsf({commit}) {
            commit('setLoading', true);
            Vue.http.get('/JSON/useful.json')
                .then(response => response.json())
                .then(json => {
                    commit('setLoadedUsf', json);
                    commit('setLoading', false);
                })
                .catch(error => {
                    console.error(error);
                    commit('setLoading', false);
                })
        }
    },
    getters: {
        loadedUsf(state) {
            return state.loadedUsf;
        },
        loadedSingleUsf(state) {
            return usfId => {
                return state.loadedUsf.find(usfOnce => {
                    return usfOnce.title === usfId;
                })
            }
        }
    }
}