import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex);

import menu from './modules/menu';
import menuFooter from './modules/footerMenu';
import servicesStore from './modules/Services/servicesStore';

export const store = new Vuex.Store({
	modules: {
		menu,
        menuFooter,
        servicesStore

	},
	strict: process.env.NODE_ENV !== 'production'
});