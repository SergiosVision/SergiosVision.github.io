import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex);

import menu from './modules/menu';
import menuFooter from './modules/footerMenu';
import servicesStore from './modules/Services/servicesStore';
import shared from './modules/shared';
import newsStore from './modules/News/newsStore';
import usefulStore from './modules/Usf/usfStore';
import contacts from './modules/Contacts/contacts';

export const store = new Vuex.Store({
	modules: {
        shared,
		menu,
        menuFooter,
        servicesStore,
        newsStore,
        usefulStore,
        contacts

	},
	strict: process.env.NODE_ENV !== 'production'
});