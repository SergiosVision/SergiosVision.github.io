<template>
    <swiper :options="swiperOption" ref="mySwiper">
        <swiper-slide v-for="(item, index) in data" :key="index">
            <carousel-card :data="item"></carousel-card>
        </swiper-slide>
        <div class="swiper-button-prev" slot="button-prev"></div>
        <div class="swiper-button-next" slot="button-next"></div>
        <!--<div class="swiper-pagination" slot="pagination"></div>-->
    </swiper>
</template>

<script>
    import { swiper, swiperSlide } from 'vue-awesome-swiper';

    export default {
        props: ['data'],
        components: {
            swiper,
            swiperSlide
        },
        name: 'carrousel',
        data() {
            return {
                swiperOption: {
                    slidesPerView: 'auto',
                    spaceBetween: 72,
                    freeMode: true,
//                    pagination: {
//                        el: '.swiper-pagination',
//                        dynamicBullets: true
//                    },
                    navigation: {
                        nextEl: '.swiper-button-next',
                        prevEl: '.swiper-button-prev'
                    }
                }
            }
        },
        computed: {
            swiper() {
                return this.$refs.mySwiper.swiper
            },
        },
        mounted() {
            this.swiper.slideTo(0, 1000, false)
        }
    }
</script>
