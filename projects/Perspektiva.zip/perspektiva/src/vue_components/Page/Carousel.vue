<template>
    <swiper :options="swiperOption" ref="mySwiper">
        <swiper-slide v-for="(slide, index) in slides" :key="index">
            <div class="t-mainPageCarouselCard">
                <img :src="slide.img" :alt="slide.title">
                <div class="t-mainPageCarouselInfo">
                    <div class="t-blur"></div>
                    <div class="t-mainPageTitleWrapper">
                        <span>{{ slide.title }}</span>
                    </div>
                    <div class="t-mainPageDescriptionWrapper">
                        <p>{{ slide.description }}</p>
                    </div>
                    <div class="t-mainPageMore">
                        <a class="t-btn" :href="slide.link">Подробнее</a>
                    </div>
                </div>
            </div>
        </swiper-slide>
        <div class="swiper-button-prev" slot="button-prev"></div>
        <div class="swiper-button-next" slot="button-next"></div>
        <!--<div class="swiper-pagination" slot="pagination"></div>-->
    </swiper>
</template>

<script>
    import { swiper, swiperSlide } from 'vue-awesome-swiper';

    export default {
        components: {
            swiper,
            swiperSlide
        },
        props: ['slides'],
        data() {
            return {
                swiperOption: {
                    slidesPerView: 1,
                    speed: 1000,
                    loop: true,
//                    pagination: {
//                        el: '.swiper-pagination',
//                        dynamicBullets: true
//                    },
                    navigation: {
                        nextEl: '.swiper-button-next',
                        prevEl: '.swiper-button-prev'
                    },
                    autoplay: {
                        delay: 5000,
                        disableOnInteraction: false
                    }
                }
            }
        },

    }
</script>

<style>

</style>