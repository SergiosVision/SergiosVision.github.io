<template>
    <div class="t-smallDialogWrapper">
        <div class="t-overlay" @click="hideModal() + clearAll()">
            <div @click="hideModal() + clearAll()" class="t-smallDialogClose">
                <svg width="10" height="10" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M1.691.29a.99.99 0 1 0-1.4 1.401L3.598 5 .29 8.309a.99.99 0 1 0 1.401 1.4l3.31-3.308L8.308 9.71a.99.99 0 1 0 1.4-1.4L6.402 5 9.71 1.692A.99.99 0 1 0 8.309.29L5 3.599 1.691.29z" fill="#2574CF"/></svg>
            </div>
        </div>
        <div class="t-smallDialogCard">
            <div class="t-smallDialogTitleWrapper">
                <h3>Обратная связь</h3>
            </div>
            <div class="t-smallDialogFormWrapper">
                <form>
                    <div class="t-inputsHolderWrapper">
                        <div class="t-inputHolder">
                            <label for="name">Ваше имя</label>
                            <input v-model="name" id="name" type="text">
                        </div>
                        <div class="t-inputHolder">
                            <label for="mail">Электронная почта</label>
                            <input v-model="mail" id="mail" type="email">
                        </div>
                        <div class="t-inputHolder">
                            <label for="message">Сообщение</label>
                            <textarea v-model="message" id="message" type="text"></textarea>
                        </div>
                    </div>
                    <div class="t-btnAndAgreement">
                        <div class="t-smallDialogSendBtnHolder">
                            <button @click.prevent="hideModal() + clearAll()" class="t-btn" type="button">Отправить сообщение</button>
                        </div>
                        <div class="t-smallDialogSendAgreementHolder">
                            <p>Нажимая кнопку «Софрмировать резюме» вы соглашаетесь с правилами обработки персональных данных</p>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>



<script>
    import { mapState, mapMutations} from 'vuex';
    export default {
        name: 'FeedbackDialog',
        data() {
            return {
                name: '',
                mail: '',
                message: ''
            }
        },
        methods: {
            ...mapMutations(['hideModal']),
            clearAll() {
                this.name = '';
                this.mail = '';
                this.message = '';
            },
        },
    }
</script>

<style>

</style>