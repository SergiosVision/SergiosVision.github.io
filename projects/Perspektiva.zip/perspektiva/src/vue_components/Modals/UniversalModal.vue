<template>
    <div class="t-mainDialogWrapper">
        <div @click="$router.push(redirect)" class="t-dialogOverlay"></div>
        <div class="t-mainDialog">
            <svg @click="$router.push(redirect)" class="t-mainDialogClose" width="21" height="21" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M9.086 10.5L.543 19.042l1.416 1.414 8.541-8.541 8.541 8.541 1.416-1.414-8.543-8.542 8.541-8.541L19.041.545 10.5 9.085 1.959.545.545 1.959l8.54 8.541z" fill="#fff"/></svg>
            <div class="t-mainDialogHeader">
                <div class="t-mainDialogMainImg">
                    <slot name="mainImage"></slot>
                </div>
            </div>
            <div class="t-mainDialogBody">
                <div class="t-mainDialogDateAndTag">
                    <div class="t-mainDialogTag"><slot name="tag"></slot></div>
                    <slot name="date"></slot>
                </div>
                <div class="t-mainDialogTitleWrapper"><slot name="title"></slot></div>
                <div class="t-mainDialogSocialSharingWrapper">
                    <span>поделиться в соцсетях:</span>
                    <ul class="t-mainList">
                        <li><a href="#">f</a></li>
                        <li><a href="#">ok</a></li>
                        <li><a href="#">vk</a></li>
                        <li><a href="#">tw</a></li>
                        <li><a href="#">G+</a></li>
                    </ul>
                </div>
                <div class="t-mainDialogOutputContentWrapper"><slot name="content"></slot></div>
            </div>
            <div class="t-mainDialogFooter">
                <div class="t-mainDialogSocialSharingWrapper">
                    <span>поделиться в соцсетях:</span>
                    <ul class="t-mainList">
                        <li><a href="#">f</a></li>
                        <li><a href="#">ok</a></li>
                        <li><a href="#">vk</a></li>
                        <li><a href="#">tw</a></li>
                        <li><a href="#">G+</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</template>



<script>
    export default {
        data() {
            return {

            }
        },
        props: ['redirect'],
        methods: {

        },
        mounted() {
            console.log(this.redirect)
        }
    }
</script>

<style>

</style>