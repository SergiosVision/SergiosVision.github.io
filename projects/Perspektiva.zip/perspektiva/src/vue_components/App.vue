<template>
  <div class="t-wrapper">
      <Header></Header>
      <main>
        <router-view></router-view>
        <small-dialog v-if="visible"></small-dialog>
      </main>
      <Footer></Footer>
  </div>
</template>



<script>
    import Header from './header/Header'
    import Footer from './footer/Footer'
    import { mapGetters } from 'vuex'
    export default {
        metaInfo: {
            title: 'Перспектива | Главная',
        },
        data() {
            return {
                dialogActive: true
            }
        },
        components: {
            'Header': Header,
            'Footer': Footer
        },
        computed: {
            ...mapGetters({
                visible: 'call',
            }),
        },
        methods: {

        },
    }
</script>

<style>
  
</style>