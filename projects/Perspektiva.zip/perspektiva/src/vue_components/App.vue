<template>
  <div class="t-wrapper">
      <Header></Header>
      <main>
        <router-view></router-view>
      </main>
      <Footer></Footer>
  </div>
</template>



<script>
    import Header from './header/Header'
    import Footer from './footer/Footer'

    export default {
        data() {
            return {

            }
        },
        components: {
            'Header': Header,
            'Footer': Footer
        },
        methods: {

        },
    }
</script>

<style>
  
</style>