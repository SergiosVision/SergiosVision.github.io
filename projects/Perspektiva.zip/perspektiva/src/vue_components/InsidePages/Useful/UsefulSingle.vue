<template>
    <div v-if="loading" style="text-align: center">Загрузка</div>
    <main-dialog v-else :redirect="route" :dialogInfo="usfSingle"></main-dialog>
</template>



<script>
    import Vue from 'vue';
    export default {
        data() {
            return {
                date: ''
            }
        },
        props: ['slug','route'],
        computed: {
            usfSingle() {
                return this.$store.getters.loadedSingleUsf(this.slug);
            },
            loading() {return this.$store.getters.loading;},
        }
    }
</script>

<style>

</style>