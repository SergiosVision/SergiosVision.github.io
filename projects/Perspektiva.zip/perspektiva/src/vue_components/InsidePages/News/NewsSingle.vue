<template>
    <div v-if="loading" style="text-align: center">Загрузка</div>
    <main-dialog v-else :redirect="route" :dialogInfo="newsSingle"></main-dialog>
</template>



<script>
    import Vue from 'vue';
    import { store } from '../../../store';
    import { mapGetters } from 'vuex';
    export default {
        metaInfo() {
            return {
                title: this.loading ? '' : 'Новости',
                titleTemplate: this.loading ? '' : '%s | '+ this.newsSingle.title +''
            }
        },
        data() {
            return {
                date: ''
            }
        },
        props: ['slug','route'],
        computed: {
            ...mapGetters('newsStore', {
                news: 'loadedNews',
            }),
            newsSingle() {
                return this.$store.getters.loadedNewsSingle(this.slug);
            },
            loading() {
                return this.$store.getters.loading;
            },
        }
    }
</script>

<style>

</style>