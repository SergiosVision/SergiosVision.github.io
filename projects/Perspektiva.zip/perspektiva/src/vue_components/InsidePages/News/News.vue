<template>
    <div class="t-wrapperNews t-mainInsideContainer">
        <div class="t-insideBgHolder">
            <div class="t-insideBgHolderOverlay">
                <h3 class="t-insideBgHolderTitle">Новсти</h3>
            </div>
        </div>
        <div class="t-container">
            <div v-if="loading" style="text-align: center">Загрузка</div>
            <div class="t-newsCardsHolder" v-else>
                <news-card :news="item" v-for="(item, index) in news" :key="index"></news-card>
            </div>
            <button class="t-btn t-moreBtn">Больше Новостей</button>
        </div>
        <router-view :route="path"></router-view>
    </div>
</template>



<script>
    export default {
        metaInfo: {
            title: 'Новости',
        },
        data() {
            return {
                path: this.$router.currentRoute.matched[0].path
            }
        },
        computed: {
            news() {return this.$store.getters.loadedNews},
            loading() {return this.$store.getters.loading;},
        },
        created() {
            this.$store.dispatch('loadNews')
        }
    }
</script>

<style>

</style>