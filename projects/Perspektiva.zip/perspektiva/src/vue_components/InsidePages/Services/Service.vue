<template>
    <div v-if="loading" style="text-align: center">Загрузка</div>
    <main-dialog v-else :redirect="route">
        <img slot="mainImage" :src="service.img" :alt="service.title">
        <span v-if="service.tag !== ''" slot="tag">{{ service.tag }}</span>
        <div v-if="service.date !== ''" slot="date" class="t-mainDialogDate">
            <svg width="16" height="18" viewBox="0 0 16 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12.444 8.1H3.556v1.8h8.888V8.1zm1.778-6.3h-.889V0h-1.777v1.8H4.444V0H2.667v1.8h-.89C.792 1.8.01 2.61.01 3.6L0 16.2c0 .99.791 1.8 1.778 1.8h12.444C15.2 18 16 17.19 16 16.2V3.6c0-.99-.8-1.8-1.778-1.8zm0 14.4H1.778V6.3h12.444v9.9zm-4.444-4.5H3.556v1.8h6.222v-1.8z" fill="#000"/></svg>
            <span>{{ service.date }}</span>
        </div>
        <h1 slot="title">{{ service.title }}</h1>
        <div slot="content" class="t-mainDialogOutputContent" v-html="service.content"></div>
    </main-dialog>
</template>



<script>
    import Vue from 'vue';
    export default {
        data() {
            return {
                date: '',
            }
        },
        props: ['slug','route'],
        computed: {
            service() {
                return this.$store.getters.loadedService(this.slug);
            },
            loading() {return this.$store.getters.loading;}
        },
    }
</script>

<style>

</style>