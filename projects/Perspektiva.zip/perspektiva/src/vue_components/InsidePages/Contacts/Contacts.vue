<template>
    <div class="t-wrapperContacts t-mainInsideContainer">
        <div class="t-insideBgHolder">
            <div class="t-insideBgHolderOverlay">
                <h3 class="t-insideBgHolderTitle">Контакты</h3>
            </div>
        </div>
        <div class="t-container">
            <!--<div v-if="loading" style="text-align: center">Загрузка</div>-->
            <div class="t-contactsCardsHolder">
                <div class="t-accordionCard" :class="cl(index)" v-for="(item, index) in contacts" :key="index">
                    <div class="t-accordionHeader" @click="toggleAccordion(index)">
                        <h2 class="t-mainTitle">{{ item.name }}</h2>
                        <span class="t-accordionArrowHolder">
                            <svg width="18" height="10" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.5 9L9 1.5 16.5 9" stroke="#2574CF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                        </span>
                    </div>
                    <transition name="accordion"
                                v-on:before-enter="beforeEnter" v-on:enter="enter"
                                v-on:before-leave="beforeLeave" v-on:leave="leave">
                        <div class="t-accordionBody" v-show="isOpen == index">
                            <div class="t-accordionContent">
                                <div class="t-aboutOrganizationMainInfo">
                                    <div class="t-aboutOrganizationInfoHolder">
                                        <p>{{ item.about }}</p>
                                    </div>
                                    <div class="t-aboutOrganizationAddressWrapper t-space">
                                        <small class="t-aboutOrganizationAddressTitle t-aboutOrganizationTitle">адрес</small>
                                        <span class="t-aboutOrganizationAddress t-aboutOrganizationContent">{{ item.address }}</span>
                                        <div class="t-yaMapWrapper t-mapWrapper">
                                            <span @click="toggleMap(index)" class="t-showOnTheMap">показать на карте</span>
                                            <transition name="mapSlide">
                                                <ya-map :index="index" :companyData="item" :loading="loading" v-show="mapVisible"></ya-map>
                                            </transition>
                                        </div>
                                    </div>
                                    <div class="t-aboutOrganizationEmailHolder t-space">
                                        <small class="t-aboutOrganizationEmailTitle t-aboutOrganizationTitle">e-mail</small>
                                        <span class="t-aboutOrganizationEmail t-aboutOrganizationContent">{{ item.mail }}</span>
                                    </div>
                                    <div class="t-aboutOrganizationPhoneWrapper t-space">
                                        <small class="t-aboutOrganizationPhoneTitle t-aboutOrganizationTitle">телефон</small>
                                        <span class="t-aboutOrganizationPhone t-aboutOrganizationContent">{{ item.phone }}</span>
                                    </div>
                                </div>
                                <div class="t-aboutOrganizationCarouselWrapper" :class="item.peoples.length <= 3?'noCarousel':''">
                                    <swiper-carousel v-if="item.peoples.length > 3" :data="item.peoples"></swiper-carousel>
                                    <carousel-card :data="data" v-else v-for="(data, i) in item.peoples" :key="i"></carousel-card>
                                </div>
                            </div>
                        </div>
                    </transition>
                </div>
            </div>
        </div>
    </div>
</template>



<script>
    import SwiperCarousel from '../../Page/SwiperCarousel.vue';
    import Vue from 'vue';
    import { mapActions, mapGetters } from 'vuex';
    import { store } from '../../../store';
    export default {
        metaInfo: {
            title: 'Контакты',
        },
        components: {
            'swiper-carousel': SwiperCarousel,
        },
        data() {
            return {
                isOpen: 0,
                mapVisible: false
            }
        },
        computed: {
            ...mapGetters('contacts',{
                contacts: 'loadedContacts'
            }),
            loading() {return this.$store.getters.loading},
        },
        methods: {
            ...mapActions('contacts', {
                loadContacts: 'loadContacts'
            }),
            toggleMap(index) {
                if(index){
                    console.log(index)
                }
            },
            cl(index) {return this.isOpen === index ? 'is-opened' : '';},
            toggleAccordion(index) {
                document.querySelector('.t-accordionBody').style.maxHeight = document.querySelector('.t-accordionBody').scrollHeight + 'px';
                if(this.isOpen === index) {
                    this.isOpen = -1;
                } else {
                    this.isOpen = index;
                }
            },
            beforeEnter: function(el) {
                el.style.maxHeight = '0';
            },
            enter: function(el) {
                    el.style.maxHeight = el.scrollHeight + parseInt(window.getComputedStyle(document.querySelector('.t-yaMapHolder'), null).height) + 'px'
            },
            beforeLeave: function(el) {
                    el.style.maxHeight = el.scrollHeight + parseInt(window.getComputedStyle(document.querySelector('.t-yaMapHolder'), null).height) + 'px';
            },
            leave: function(el) {
                el.style.maxHeight = '0';
            }
        },
        created() {
            console.log(this.contacts);
        },
        beforeRouteEnter(to, from, next) {
            Vue.http.get('/JSON/organizations.json')
                .then(response => response.json())
                .then(data => {
                    next(store.dispatch('contacts/loadContacts', data))
                })
        },
    }
</script>

<style>

</style>