<template>
    <social-sharing :url="currentRote"
                    :title="sharingData.title"
                    :description="sharingData.title"
                    :quote="sharingData.title"
                    :hashtags="sharingData.tag"
                    inline-template>
        <div>
            <network network="facebook">
                <i class="fa fa-facebook"></i> Facebook
            </network>
            <network network="odnoklassniki">
                <i class="fa fa-odnoklassniki"></i> Odnoklassniki
            </network>
            <network network="vk">
                <i class="fa fa-vk"></i> VKontakte
            </network>
            <network network="twitter">
                <i class="fa fa-twitter"></i> Twitter
            </network>
            <network network="googleplus">
                <i class="fa fa-google-plus"></i> Google +
            </network>
        </div>
    </social-sharing>
</template>



<script>
    import Vue from 'vue';
    import SocialSharing from 'vue-social-sharing';
    Vue.use(SocialSharing);
    export default {
        data() {
            return {

            }
        },
        props: ['sharingData', 'currentRote'],
        computed: {

        },
    }
</script>

<style>

</style>