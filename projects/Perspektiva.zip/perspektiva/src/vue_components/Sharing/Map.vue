<template>
    <div class="t-yaMapHolder" :id="'t-yandexMap_' + index"></div>
</template>



<script>
    export default {
        props: ['index', 'companyData', 'loading'],
        data() {
            return {

            }
        },
        computed: {

        },
        mounted() {
            if(this.loading) {
                return
            } else {
                ymaps.ready(res => res)
                    .then(res => {
                        res.geocode(this.companyData.address).then(resInside => {
                            const myMap = new res.Map('t-yandexMap_' + this.index, {
                                center: resInside.geoObjects.get(0).geometry.getCoordinates(),
                                zoom : 15,
                                controls: []
                            });
                            const myPlacemark = new res.Placemark(myMap.getCenter(), {
                                balloonContentBody: [
                                    '<address>',
                                    '<strong>'+ this.companyData.name +'</strong>',
                                    '<br/>',
                                    '<span>Адрес: <span>'+ this.companyData.address +'</span></span>',
                                    '<br/>',
                                    '<span>E-mail: <span>'+ this.companyData.mail +'</span></span>',
                                    '<br/>',
                                    '<span>Телефон: <span>'+ this.companyData.phone +'</span></span>',
                                    '<br/>',
                                    '</address>'
                                ].join(''),

                                preset: 'islands#redDotIcon'
                            });
                            myMap.geoObjects.add(myPlacemark);
                        })
                    })
            }
        }
    }
</script>

<style>

</style>