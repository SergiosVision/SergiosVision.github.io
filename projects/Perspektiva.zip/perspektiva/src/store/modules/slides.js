export default {
    namespaced: true,
    state: {
        loadedSlides: []
    },
    mutations: {
        setLoadedSlides(state, payload) {
            state.loadedSlides = payload;
        }
    },
    actions: {
        loadSlides(context, data) {
            context.commit('setLoadedSlides', data);
        }
    },
    getters: {
        loadedSlides(state) {
            return state.loadedSlides;
        }
    }
}