import Vue from 'vue';
export default {
    state: {
        loadedServices: []
    },
    mutations: {
        setLoadedServices(state, payload) {
            state.loadedServices = payload;
        }
    },
    actions: {
        loadServices({commit}) {
            commit('setLoading', true);
            Vue.http.get('/JSON/services.json')
                .then(response => response.json())
                .then(json => {
                    commit('setLoadedServices', json);
                    commit('setLoading', false);
                })
                .catch(error => {
                    console.error(error);
                    commit('setLoading', false);
            });
        }
    },
    getters: {
        loadedServices(state) {
            return state.loadedServices;
        },
        loadedService(state) {
            return serviceId => {
                return state.loadedServices.find(service => {
                    return service.title === serviceId;
                })
            }
        }
    }
}