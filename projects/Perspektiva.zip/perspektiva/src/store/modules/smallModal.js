export default {
    state: {
        modalVisible: false,
    },
    mutations: {
        showModal(state) {
            state.modalVisible = true;
        },
        hideModal(state) {
            state.modalVisible = false;
        }
    },
    getters: {
        call(state) {
            return state.modalVisible;
        }
    }
}