import Vue from 'vue';
export default {
    state: {
        loadedContacts: []
    },
    mutations: {
        setLoadedContacts(state, payload) {
            state.loadedContacts = payload;
        }
    },
    actions: {
        loadContacts({commit}) {
            commit('setLoading', true);
            Vue.http.get('/JSON/organizations.json')
                .then(response => response.json())
                .then(json => {
                    commit('setLoadedContacts', json);
                    commit('setLoading', false);
                })
                .catch(error => console.error(error));
        }
    },
    getters: {
        loadedContacts(state) {
            return state.loadedContacts;
        }
    }
}