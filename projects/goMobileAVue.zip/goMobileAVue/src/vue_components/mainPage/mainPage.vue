<template>
    <div class="t-mainContentContainer">
        <section class="t-hiSectionWrapper">
            <div class="t-leftSideHolder">
                <div class="t-leftSide">
                    <div class="t-hiSectionLeftHeader">
                        <div class="t-hiContainer t-figure">
                            <p>Привет! 👋 Мы агентство мобильного маркетинга Go Mobile</p>
                        </div>
                    </div>
                    <div class="t-hiSectionLeftBody">
                        <div class="t-hiBodyDescriptionContainer">
                            <p>Для клиентов делаем full-mobile — от креативов и UX до стратегии и performance-маркетинга.</p>
                        </div>
                    </div>
                    <div class="t-hiSectionLeftFooter">
                        <button class="t-btn">
                            <span>Написать нам</span>
                            <svg width="35" height="26" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.805 1H34v23.588H1.805V1zm0 0l16.097 13.938 8.586-6.433" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                        </button>
                    </div>
                </div>
            </div>
            <div class="t-rightSide">
                <img src="/images/mobilePhone.jpg" alt="">
            </div>
        </section>
        <section class="t-servicesWrapper">
            <h2 class="t-title">Услуги</h2>
            <div class="t-servicesSlidesHolder">
                <div class="t-servicesCard">
                    <div class="t-servicesCardImgAndTitleWrapper">
                        <img src="/images/icons/SVG-optim/user.svg" alt="">
                        <span>Branding</span>
                    </div>
                    <div class="t-servicesCardDescription">
                        <p>Имиджевые рекламные кампании

                            👍🏻 Оптимизация по показателям post-click
                            👍🏻 Повышение узнаваемости бренда
                            👍🏻 Выгодные условия закупки
                            👍🏻 Бесплатный продакшн креативов
                            👍🏻 Brand safety

                            1 пункт = Оптимизация по показателям взаимодействия с рекламными материалами/сайтом/приложением.</p>
                    </div>
                </div>
            </div>
        </section>
        <section class="t-casesWrapper">
            <h2 class="t-title">Кейсы</h2>
            <div class="t-casesHolder">
                <div class="t-casesCard">
                    <div class="t-casesLeft">
                        <img src="/images/midMobile.jpg" alt="">
                    </div>
                    <div class="t-casesRightSideHolder">
                        <div class="t-casesRight">
                            <div class="t-casesInfoHeader">
                                <h4>Продвижение приложения BlaBlaCar</h4>
                            </div>
                            <div class="t-casesInfoBody">
                                <div class="t-casesBodyDescriptionContainer t-figure">
                                    <p>👍 Привлечение новых водителей и пассажиров</p>
                                    <p>👍 KPI по стоимости регистрации новых пользователей</p>
                                </div>
                            </div>
                            <div class="t-casesInfoFooter">
                                <div class="t-casesSubCard">
                                    <span class="t-casesSubTitle">8%</span>
                                    <p class="t-casesSubDescription">конверсия из перехода на сайт в репост</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="t-feedbackWrapper">
            <h2 class="t-title">Обратная связь</h2>
            <div class="t-feedbackFormWrapper">
                <div class="t-formTitle">Ваше сообщение</div>
                <form>
                    <div class="t-formInputsHolder">
                        <div class="t-formSingleLine">
                            <div class="t-inputWrapper">
                                <input placeholder="Имя" type="text">
                            </div>
                            <div class="t-inputWrapper">
                                <input placeholder="Почта или телефон" type="text">
                            </div>
                        </div>
                        <div class="t-inputWrapper">
                            <textarea placeholder="Ваш комментарий, вопрос или идея"></textarea>
                        </div>
                    </div>
                    <div class="t-buttonAndAgreement">
                        <button class="t-btn" type="button">
                            <span>Отправить</span>
                            <svg width="35" height="26" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.805 1H34v23.588H1.805V1zm0 0l16.097 13.938 8.586-6.433" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                        </button>
                        <div class="t-agreement">
                            <p>Нажимая кнопку «Отправить сообщение», вы соглашаетесь с <a href="#">правилами</a> обработки персональный данных на этом сайте</p>
                        </div>
                    </div>
                </form>
            </div>
        </section>
    </div>
</template>

<script>
    export default {

    }
</script>

<style>

</style>