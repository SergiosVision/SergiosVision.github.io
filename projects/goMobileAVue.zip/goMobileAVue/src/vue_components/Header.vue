<template>
    <header>
        <div class="t-headerLeft">
            <div class="t-headerLogoWrapper"><router-link to="/" tag="a"><img src="/images/logo.png"></router-link></div>
            <div class="t-languageSwitcherWrapper">
                <div class="t-languageSwither"><span>RU</span></div>
                <div class="t-languageList"></div>
            </div>
        </div>
        <div class="t-headerRight">
            <nav>
                <ul>
                    <li><a href="#">Кейсы</a></li>
                    <li><a href="#">Проекты</a></li>
                    <li><a href="#">Блог</a></li>
                    <li><a href="#">Контакты</a></li>
                </ul>
            </nav>
        </div>
    </header>
</template>

<script>
    import {mapGetters} from 'vuex';

    export default {
        computed: {
            ...mapGetters('menu', {
                menuList: 'items'
            })
        }
    }
</script>

<style>

</style>