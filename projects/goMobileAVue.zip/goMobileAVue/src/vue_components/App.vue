<template>
  <div class="t-warapper">
    <header-app></header-app>
    <main>
      <router-view></router-view>
    </main>
    <footer-app></footer-app>
  </div>
</template>

<script>
    import Header from './Header';
    import Footer from './Footer';
    export default {
      components: {
        'header-app': Header,
        'footer-app': Footer,
      }
    }
</script>

<style>

</style>