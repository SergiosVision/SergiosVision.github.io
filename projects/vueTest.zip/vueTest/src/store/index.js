import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex);

import menu from './modules/menu';
import items from './modules/items';

export const store = new Vuex.Store({
	modules: {
		menu,
        items
	},
	strict: process.env.NODE_ENV !== 'production'
});