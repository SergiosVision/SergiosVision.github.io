export default {
    namespaced: true,
    state: {
        items: [],
        singleItem: null
    },
    mutations: {
        setLoadedItems(state, payload) {
            state.items = payload;
        },
        setLoadedSingleItem(state, payload) {
            state.singleItem = payload;
        }
    },
    actions: {
        loadItems({ commit }, data) {
            commit('setLoadedItems', data);
        },
        loadSingleItem({ commit }, data) {
            commit('setLoadedSingleItem', data);
        }
    },
    getters: {
        itemsGet(state){
            return state.items;
        },
        getExactItem(state) {
            return state.singleItem
        },
    }
};