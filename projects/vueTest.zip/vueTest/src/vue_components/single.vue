<template>
    <div class="singleHolder">
        <div class="sv-inputHolder">
            <div class="group">
                <input type="text" required>
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Name</label>
            </div>
        </div>
        <div class="sv-singlePage">
            <div class="sv-singlePageTitle">
                <h1>{{ single.title }}</h1>
            </div>
            <div class="sv-singlePageImg">
                <img :src="single.thumbnail" :alt="single.title">
            </div>
            <div class="sv-singlePageInfo" style="display: flex; align-items: center; justify-content: space-between;">
                <div class="sv-singlePageInfoTime">
                    <span>{{ single.cookTime }}</span>
                </div>
                <div class="sv-singlePageInfoDif">
                    <span>{{ single.difficulty }}</span>
                </div>
                <div class="sv-singlePageInfoCal">
                    <span>{{ single.caloricity }}</span>
                </div>
                <div class="sv-singlePageCuisine">
                    <span>
                        {{ single.cuisine.title }}
                    </span>
                </div>
            </div>
            <div class="sv-singlePageImages">
                <div class="sv-singlePageCardImg" v-for="(item, indxe) in single.images">
                    <img :src="item">
                </div>
            </div>
            <div class="sv-singlePageIngredients">
                <ul>
                    <li v-for="(item, index) in single.ingredients" :key="index">
                        {{ item }}
                    </li>
                </ul>
            </div>
            <div class="sv-singlePageInstructions" style="margin-top: 50px;">
                <ul>
                    <li v-for="(item, index) in single.instructions" :key="index">
                        {{ item }}
                    </li>
                </ul>
            </div>
        </div>
    </div>
</template>

<script>
    import Vue from 'vue';
    import { mapGetters } from 'vuex';
    import { store } from '../store';

    export default {
        data() {
            return {

            }
        },
        computed: {
            ...mapGetters('items', {
                single: 'getExactItem'
            })
        },
        beforeRouteEnter(to, from, next) {
            Vue.http.get(`https://test.space-o.ru/detail_${to.params.id}.json`)
                .then(response => response.json())
                .then(json => {
                    store.dispatch('items/loadSingleItem', json.recipe);
                    next()
                })
        },
        mounted() {
            console.log(this.single)
        }
    }
</script>