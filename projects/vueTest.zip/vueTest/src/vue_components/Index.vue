<template>
	<div>
		<filter-app :filterData="recipesRes"></filter-app>
		<div class="sv-cardHolder">
			<div class="sv-card" v-for="(item, index) in recipesRes" :key="index" :data-id="item.id">
				<div class="sv-cardImg">
					<img :src="item.thumbnail" :alt="item.title">
				</div>
				<div class="sv-cardContent">
					<div class="sv-cardContentTitle">
						<h3>{{ item.title }}</h3>
					</div>
					<div class="sv-cardContentInfo">
						<span class="sv-cardContentInfoCuisine">{{ item.cuisine.title }}</span>
						<span class="sv-cardContentInfoCaloricity">{{ item.caloricity }}</span>
					</div>
					<div class="sv-cardContentDescription">
						<p>{{ item.description }}</p>
					</div>
				</div>
				<div class="sv-cardActions">
					<router-link tag="a" :to="'/recipes/'+ item.id">
						<span>Read more</span>
					</router-link>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
    import Vue from 'vue';
    import { mapGetters } from 'vuex';
    import { store } from '../store';

    export default {
        computed: {
            ...mapGetters('items', {
                recipesRes: 'itemsGet'
            })
        },
        beforeRouteEnter(to, from, next) {
            Vue.http.get('https://test.space-o.ru/list.json')
                .then(response => response.json())
                .then(data => {
                    next(store.dispatch('items/loadItems', data.recipes))
                })
        },
        mounted() {

        }
	}
</script>