<template>
    <div class="sv-cardHolderF">
        <button>Open</button>
        <div class="sv-filterCard">
            <div class="sv-cardHeader">
                <div class="sv-cardLeft">
                    <span>Clear filter</span>
                </div>
                <div class="sv-cardRight">
                    <button>Filter This</button>
                </div>
            </div>
            <div class="sv-cardBody">
                <ul>
                    <li v-for="(item, index) in localFilterData" :key="index">
                        <input :data-idinput="item.id" :id="item.title.toLocaleLowerCase()" :name="item.title.toLocaleLowerCase()" type="checkbox">
                        <label :for="item.title.toLocaleLowerCase()">{{ item.title }}</label>
                    </li>
                </ul>
            </div>
            <div class="sv-cardFooter">

            </div>
        </div>
    </div>
</template>

<script>
    import Vue from 'vue';
    import { mapGetters } from 'vuex';
    import { store } from '../store';

    export default {
        props: ['filterData'],
        data() {
            return {
                localFilterData: [
                    {
                        title: 'Caribbean',
                        id: '1'
                    },
                    {
                        title: 'Greek',
                        id: '2'
                    },
                    {
                        title: 'French',
                        id: '3'
                    },
                    {
                        title: 'Indian',
                        id: '5'
                    },
                    {
                        title: 'Chinese',
                        id: '4'
                    }
                ]
            }
        },
        mounted() {

        }
    }
</script>